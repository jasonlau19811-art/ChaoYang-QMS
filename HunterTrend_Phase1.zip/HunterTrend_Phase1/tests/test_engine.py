from huntertrend.data import demo_data
from huntertrend.engine import analyze
from huntertrend.backtest import backtest

def test_pipeline():
    df=demo_data()
    r=analyze(df,{"roe":15,"profit_growth":12,"debt_ratio":42,"pe":28})
    assert 0 <= r["score"] <= 100
    assert 0 <= r["position"] <= 85
    bt,m=backtest(df)
    assert len(bt)>0 and "最大回撤" in m
