# HunterTrend Pro 第一阶段

可在安卓手机与电脑浏览器使用的 A 股多模型量化决策 Web 应用。

## 已完成功能

- 默认自选：汇川技术 300124、特变电工 600089、创业板ETF 159915
- AKShare 在线行情、CSV/XLSX 上传及演示数据
- 趋势、均值回归、动量、随机森林、逻辑回归、风险、基本面模型
- 综合评分、上涨概率、信号置信度、建议仓位、ATR止损与目标价
- 近180日K线和含交易成本的规则层回测
- 安卓响应式界面
- Streamlit Cloud 与 Render/Docker 部署文件

## 本地启动

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Windows 可双击 `run_windows.bat`。

## Streamlit Community Cloud 部署

1. 将整个文件夹上传到 GitHub 仓库。
2. 在 Streamlit Community Cloud 新建应用。
3. Repository 选择该仓库，Main file path 填写 `app.py`。
4. 部署成功后，用安卓浏览器打开网址并“添加到主屏幕”。

## Render 部署

仓库已包含 `Dockerfile` 与 `render.yaml`，在 Render 连接 GitHub 仓库后可直接创建 Web Service。

## 风险说明

本系统只用于研究和辅助决策，不构成投资建议，不自动下单。机器学习结果必须结合走样本外回测、交易成本、停牌与涨跌停等实际约束评估。
