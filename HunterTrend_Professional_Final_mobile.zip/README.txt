HunterTrend Professional Final（手机版）

文件：
1. app.py
2. requirements.txt
3. sample_portfolio.csv

部署：
pip install -r requirements.txt
streamlit run app.py

Streamlit Cloud：
- 把 app.py 和 requirements.txt 上传到 GitHub 仓库根目录
- Main file path 选择 app.py
- 部署后用手机浏览器打开网址

功能：
单股专业决策、自选股雷达、策略回测、持仓管理、AI晨报、CSV导出。

重要说明：
本系统不会自动下单。免费行情可能延迟或限流，实盘前请与券商行情核对。
仅用于研究和辅助决策，不构成投资建议。
